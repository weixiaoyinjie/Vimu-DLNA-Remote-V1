package com.vimudlna.remote;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A phone-only DLNA control point for the Vimu Media Player renderer. */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 17, 27);
    private static final int CARD = Color.rgb(26, 35, 49);
    private static final int TEXT = Color.WHITE;
    private static final int SUB = Color.rgb(170, 187, 205);
    private static final int ACCENT = Color.rgb(68, 189, 174);

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService pictures = Executors.newFixedThreadPool(2);
    private final ArrayList<Upnp.Device> servers = new ArrayList<>();
    private final ArrayList<Upnp.Device> renderers = new ArrayList<>();
    private final ArrayList<Upnp.Item> currentFolderItems = new ArrayList<>();
    private final ArrayList<Upnp.Item> displayed = new ArrayList<>();
    private final ArrayDeque<Folder> stack = new ArrayDeque<>();
    private final Set<String> imageRequests = Collections.synchronizedSet(new HashSet<>());
    private final Set<String> failedImages = Collections.synchronizedSet(new HashSet<>());
    private final LruCache<String, Bitmap> imageCache = new LruCache<String, Bitmap>(12 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount() / 1024; }
    };

    private Upnp.Device server, renderer;
    private Upnp.Item playing;
    private WifiManager.MulticastLock multicastLock;
    private SharedPreferences preferences;
    private TextView status, folderTitle, nowPlaying, clock;
    private EditText search;
    private Spinner rendererList, serverList;
    private Button playPause;
    private SeekBar progress;
    private ListView files;
    private FileAdapter adapter;
    private long seconds = 0, duration = 0;
    private boolean isPlaying, isDragging, changingSpinners, screenAlive = true;
    private int folderGeneration = 0;
    private int refreshGeneration = 0;
    private String currentFolderId = "0";
    private String currentFolderName = "全部视频";

    private static class Folder {
        final String id, name;
        Folder(String id, String name) { this.id = id; this.name = name; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        preferences = getSharedPreferences("vimu_remote", MODE_PRIVATE);
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                multicastLock = wifi.createMulticastLock("VimuSSDPDiscovery");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) {}
        setupUi();
        scan();
        ui.postDelayed(poll, 3500);
    }

    @Override protected void onDestroy() {
        screenAlive = false;
        ui.removeCallbacks(poll);
        io.shutdownNow();
        pictures.shutdownNow();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.onDestroy();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color); gd.setCornerRadius(dp(radius)); return gd;
    }
    private TextView label(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(color); t.setTextSize(sp);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private Button button(String text) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(text); b.setTextColor(TEXT);
        b.setTextSize(13); b.setBackground(shape(CARD, 10));
        b.setPadding(dp(5), 0, dp(5), 0);
        return b;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private void add(LinearLayout root, View v, int height) {
        LinearLayout.LayoutParams p = lp(-1, height < 0 ? height : dp(height));
        root.addView(v, p);
    }
    private void gap(LinearLayout root, int height) { add(root, new View(this), height); }
    private void weighted(LinearLayout parent, View v, int h, float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(h), weight);
        p.setMargins(dp(3), 0, dp(3), 0); parent.addView(v, p);
    }
    private Spinner spinner() {
        Spinner s = new Spinner(this);
        s.setBackground(shape(CARD, 10));
        s.setPadding(dp(8), 0, dp(4), 0);
        return s;
    }
    private void spinnerAdapter(Spinner s, List<String> values) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
    }

    private void setupUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG); root.setPadding(dp(12), dp(12), dp(12), dp(8));
        setContentView(root);

        LinearLayout top = row();
        TextView title = label("Vimu 影库遥控", 21, true, TEXT);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        title.setGravity(Gravity.CENTER_VERTICAL);
        Button scan = button("⟳ 搜索设备");
        top.addView(scan, lp(dp(106), dp(42)));
        scan.setOnClickListener(v -> scan());
        add(root, top, 44);

        status = label("准备搜索 Vimu 和 DLNA 硬盘…", 12, false, SUB);
        add(root, status, 24);
        TextView t1 = label("电视播放器（选 Vimu）", 12, false, SUB); add(root, t1, 20);
        rendererList = spinner(); add(root, rendererList, 44);
        gap(root, 5);
        TextView t2 = label("DLNA / UPnP 硬盘", 12, false, SUB); add(root, t2, 20);
        serverList = spinner(); add(root, serverList, 44);
        spinnerAdapter(rendererList, Collections.singletonList("正在搜索播放器…"));
        spinnerAdapter(serverList, Collections.singletonList("正在搜索媒体库…"));

        rendererList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> p) {}
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (changingSpinners) return;
                renderer = pos >= 0 && pos < renderers.size() ? renderers.get(pos) : null;
                if (renderer != null) preferences.edit().putString("renderer_udn", renderer.udn).apply();
                updateStatus();
            }
        });
        serverList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> p) {}
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (changingSpinners) return;
                server = pos >= 0 && pos < servers.size() ? servers.get(pos) : null;
                if (server != null) preferences.edit().putString("server_udn", server.udn).apply();
                stack.clear(); currentFolderId = "0"; currentFolderName = "全部视频";
                if (server != null) browse("0", "全部视频", false);
                updateStatus();
            }
        });

        gap(root, 8);
        LinearLayout nav = row();
        Button back = button("← 返回");
        nav.addView(back, lp(dp(86), dp(39)));
        back.setOnClickListener(v -> upFolder());
        folderTitle = label("  硬盘目录", 15, true, TEXT);
        folderTitle.setSingleLine(true); folderTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nav.addView(folderTitle, new LinearLayout.LayoutParams(0, dp(39), 1));
        folderTitle.setGravity(Gravity.CENTER_VERTICAL);
        add(root, nav, 42);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(TEXT); search.setHintTextColor(SUB);
        search.setHint("搜索当前文件夹的视频名称");
        search.setPadding(dp(14), 0, dp(12), 0);
        search.setBackground(shape(CARD, 10));
        add(root, search, 44);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        gap(root, 6);
        files = new ListView(this);
        files.setDividerHeight(dp(2));
        files.setDivider(null);
        files.setBackgroundColor(BG);
        adapter = new FileAdapter();
        files.setAdapter(adapter);
        files.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= displayed.size()) return;
            Upnp.Item item = displayed.get(pos);
            if (item.folder) browse(item.id, item.name, true);
            else startVideo(item, -1);
        });
        root.addView(files, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(10), dp(8), dp(10), dp(7));
        bottom.setBackground(shape(CARD, 14));
        add(root, bottom, 178);

        LinearLayout headline = row();
        nowPlaying = label("尚未播放影片", 14, true, TEXT);
        nowPlaying.setSingleLine(true);
        nowPlaying.setEllipsize(android.text.TextUtils.TruncateAt.END);
        headline.addView(nowPlaying, new LinearLayout.LayoutParams(0, dp(28), 1));
        Button stop = button("停止");
        headline.addView(stop, lp(dp(49), dp(29)));
        stop.setOnClickListener(v -> control("Stop"));
        Button resume = button("▶ 继续观看");
        headline.addView(resume, lp(dp(105), dp(29)));
        resume.setOnClickListener(v -> resumeVideo());
        add(bottom, headline, 30);

        progress = new SeekBar(this);
        progress.setMax(1000);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        progress.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        add(bottom, progress, 31);
        progress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seek, int p, boolean fromUser) {
                if (fromUser && duration > 0) clock.setText(time(duration * p / 1000) + " / " + time(duration));
            }
            @Override public void onStartTrackingTouch(SeekBar seek) { isDragging = true; }
            @Override public void onStopTrackingTouch(SeekBar seek) {
                isDragging = false;
                if (duration > 0) seekTo(duration * seek.getProgress() / 1000);
                else toast("还没有读取到影片总时长");
            }
        });
        clock = label("00:00 / 00:00", 12, false, SUB);
        clock.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        add(bottom, clock, 18);
        LinearLayout controls = row();
        Button prev = button("上一部"), minus = button("-30秒");
        playPause = button("播放/暂停");
        Button plus = button("+30秒"), next = button("下一部");
        weighted(controls, prev, 43, 1.1f);
        weighted(controls, minus, 43, 1.1f);
        weighted(controls, playPause, 43, 1.6f);
        weighted(controls, plus, 43, 1.1f);
        weighted(controls, next, 43, 1.1f);
        add(bottom, controls, 45);
        prev.setOnClickListener(v -> adjacent(-1));
        next.setOnClickListener(v -> adjacent(1));
        minus.setOnClickListener(v -> seekTo(Math.max(0, seconds - 30)));
        plus.setOnClickListener(v -> seekTo(seconds + 30));
        playPause.setOnClickListener(v -> control(isPlaying ? "Pause" : "Play"));
        TextView footer = label("视频由 DLNA 硬盘直接传给电视，不经手机转发", 11, false, SUB);
        footer.setGravity(Gravity.CENTER);
        add(bottom, footer, 24);
    }

    private void task(String name, Work work) {
        io.submit(() -> {
            try { work.run(); }
            catch (Exception e) { showError(name + "失败：" + e.getMessage()); }
        });
    }
    private interface Work { void run() throws Exception; }
    private void showError(String s) { ui.post(() -> { status.setText(s); toast(s); }); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private void updateStatus() {
        status.setText((renderer == null ? "未选择 Vimu" : "Vimu: " + renderer.name) +
                "   |   " + (server == null ? "未选择硬盘" : "硬盘: " + server.name));
    }
    private void scan() {
        status.setText("正在搜索局域网设备…（约 4–10 秒）");
        final String oldRenderer = renderer == null ? preferences.getString("renderer_udn", "") : renderer.udn;
        final String oldServer = server == null ? preferences.getString("server_udn", "") : server.udn;
        task("扫描设备", () -> {
            ArrayList<Upnp.Device> found = Upnp.discover();
            ArrayList<Upnp.Device> newRenderers = new ArrayList<>(), newServers = new ArrayList<>();
            for (Upnp.Device d : found) {
                if (d.kind.contains("Renderer")) newRenderers.add(d);
                if (d.kind.contains("Server")) newServers.add(d);
            }
            ui.post(() -> {
                if (!screenAlive) return;
                changingSpinners = true;
                renderers.clear(); renderers.addAll(newRenderers);
                servers.clear(); servers.addAll(newServers);
                ArrayList<String> r = new ArrayList<>(), s = new ArrayList<>();
                for (Upnp.Device d : renderers) r.add(d.name + (d.name.toLowerCase(Locale.ROOT).contains("vimu") ? " ✓" : ""));
                for (Upnp.Device d : servers) s.add(d.name);
                if (r.isEmpty()) r.add("没有发现播放器，请确认 Vimu 已打开");
                if (s.isEmpty()) s.add("没有发现 DLNA 硬盘");
                spinnerAdapter(rendererList, r); spinnerAdapter(serverList, s);
                int ridx = findDevice(renderers, oldRenderer);
                if (ridx == -1) {
                    ridx = 0;
                    for (int i=0; i<renderers.size(); i++) {
                        if (renderers.get(i).name.toLowerCase(Locale.ROOT).contains("vimu")) { ridx = i; break; }
                    }
                }
                int sidx = findDevice(servers, oldServer);
                if (sidx == -1) sidx = 0;
                rendererList.setSelection(ridx);
                serverList.setSelection(sidx);
                renderer = renderers.isEmpty() ? null : renderers.get(ridx);
                server = servers.isEmpty() ? null : servers.get(sidx);
                changingSpinners = false;
                updateStatus();
                if (server != null) {
                    stack.clear(); currentFolderId = "0"; currentFolderName = "全部视频";
                    browse("0", "全部视频", false);
                }
                if (renderer == null || server == null) toast("请确保手机、Vimu 和 DLNA 硬盘在同一局域网");
            });
        });
    }
    private int findDevice(List<Upnp.Device> list, String udn) {
        if (udn == null || udn.isEmpty()) return -1;
        for (int i=0; i<list.size(); i++) if (udn.equals(list.get(i).udn)) return i;
        return -1;
    }

    private void browse(String id, String name, boolean push) {
        if (server == null) { toast("请先选择 DLNA 硬盘"); return; }
        final Upnp.Device target = server;
        final int generation = ++folderGeneration;
        final String fromId = currentFolderId, fromName = currentFolderName;
        folderTitle.setText("  读取：" + name);
        task("读取目录", () -> {
            ArrayList<Upnp.Item> items = Upnp.browse(target, id);
            items.removeIf(x -> !x.folder && !x.isVideo());
            items.sort((a, b) -> {
                if (a.folder != b.folder) return a.folder ? -1 : 1;
                return compareNatural(a.name, b.name);
            });
            ui.post(() -> {
                if (!screenAlive || generation != folderGeneration || server != target) return;
                if (push) stack.push(new Folder(fromId, fromName));
                currentFolderId = id; currentFolderName = name;
                currentFolderItems.clear(); currentFolderItems.addAll(items);
                folderTitle.setText("  " + name + " (" + items.size() + ")");
                search.setText(""); filter(); files.setSelection(0);
            });
        });
    }
    private static int compareNatural(String a, String b) {
        int i=0, j=0;
        while (i<a.length() && j<b.length()) {
            char ca=a.charAt(i), cb=b.charAt(j);
            if (Character.isDigit(ca) && Character.isDigit(cb)) {
                int sa=i, sb=j;
                while (i<a.length() && Character.isDigit(a.charAt(i))) i++;
                while (j<b.length() && Character.isDigit(b.charAt(j))) j++;
                String na=a.substring(sa,i).replaceFirst("^0+(?!$)", "");
                String nb=b.substring(sb,j).replaceFirst("^0+(?!$)", "");
                if (na.length()!=nb.length()) return Integer.compare(na.length(),nb.length());
                int cmp=na.compareTo(nb); if (cmp!=0) return cmp;
            } else {
                int cmp=Character.compare(Character.toLowerCase(ca),Character.toLowerCase(cb));
                if(cmp!=0) return cmp;
                i++;j++;
            }
        }
        return Integer.compare(a.length()-i, b.length()-j);
    }
    private void upFolder() {
        if (stack.isEmpty()) { toast("已经在硬盘根目录"); return; }
        Folder folder = stack.pop(); browse(folder.id, folder.name, false);
    }
    @Override public void onBackPressed() {
        if (!stack.isEmpty()) upFolder(); else super.onBackPressed();
    }
    private void filter() {
        String query = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        displayed.clear();
        for (Upnp.Item item : currentFolderItems) {
            if (query.isEmpty() || item.name.toLowerCase(Locale.ROOT).contains(query)) displayed.add(item);
        }
        adapter.notifyDataSetChanged();
    }

    private void startVideo(Upnp.Item item, long resumeAt) {
        if (renderer == null) { toast("请先选择电视上的 Vimu"); return; }
        if (item == null || item.url == null) { toast("硬盘没有提供可播放的视频地址"); return; }
        final Upnp.Device target = renderer;
        status.setText("正在交给 Vimu 播放：" + item.name);
        task("Vimu 播放", () -> {
            Upnp.play(target, item);
            ui.post(() -> {
                playing = item; nowPlaying.setText(item.name);
                isPlaying = true; playPause.setText("暂停"); seconds = 0; duration = 0;
                updateStatus(); saveHistory();
            });
            if (resumeAt > 5) {
                Thread.sleep(1800);
                try { Upnp.seek(target, resumeAt); }
                catch (Exception first) { Thread.sleep(2300); Upnp.seek(target, resumeAt); }
            }
        });
    }
    private void adjacent(int step) {
        ArrayList<Upnp.Item> videos = new ArrayList<>();
        for (Upnp.Item item : currentFolderItems) if (!item.folder && item.isVideo()) videos.add(item);
        if (playing == null || videos.isEmpty()) { toast("请先从当前目录选择影片"); return; }
        int index = -1;
        for (int i=0; i<videos.size(); i++) if (playing.url.equals(videos.get(i).url)) { index = i; break; }
        int target = index + step;
        if (index < 0 || target < 0 || target >= videos.size()) { toast("当前目录没有更多影片"); return; }
        startVideo(videos.get(target), -1);
    }
    private void control(String action) {
        if (renderer == null) { toast("未连接 Vimu"); return; }
        final Upnp.Device d = renderer;
        task(action, () -> {
            Upnp.command(d, action);
            ui.post(() -> {
                if ("Pause".equals(action)) isPlaying=false;
                if ("Play".equals(action)) isPlaying=true;
                if ("Stop".equals(action)) isPlaying=false;
                playPause.setText(isPlaying ? "暂停" : "播放");
            });
        });
    }
    private void seekTo(long targetSeconds) {
        if (renderer == null) { toast("未连接 Vimu"); return; }
        long seekTime = duration > 0 ? Math.min(duration, targetSeconds) : targetSeconds;
        Upnp.Device d = renderer;
        task("跳转进度", () -> {
            Upnp.seek(d, seekTime);
            ui.post(() -> { seconds = seekTime; refreshProgress(); saveHistory(); });
        });
    }
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!screenAlive) return;
            if (renderer != null) {
                final Upnp.Device target = renderer;
                final int token = ++refreshGeneration;
                io.submit(() -> {
                    try {
                        Upnp.Position pos = Upnp.position(target);
                        ui.post(() -> {
                            if (!screenAlive || renderer != target || token != refreshGeneration) return;
                            seconds = pos.seconds;
                            if (pos.duration > 0) duration = pos.duration;
                            if (pos.state.equals("PLAYING")) isPlaying = true;
                            else if (pos.state.contains("PAUSED") || pos.state.equals("STOPPED")) isPlaying = false;
                            playPause.setText(isPlaying ? "暂停" : "播放");
                            refreshProgress();
                            if (playing != null && seconds > 0) saveHistory();
                        });
                    } catch (Exception ignored) { /* some renderers omit position; playback still works */ }
                });
            }
            ui.postDelayed(this, 5000);
        }
    };
    private void refreshProgress() {
        if (isDragging) return;
        if (duration > 0) progress.setProgress((int)(Math.min(seconds, duration) * 1000 / duration));
        clock.setText(time(seconds) + " / " + time(duration));
    }
    private static String time(long seconds) {
        if (seconds >= 3600) return String.format(Locale.US, "%d:%02d:%02d",seconds/3600,(seconds%3600)/60,seconds%60);
        return String.format(Locale.US, "%02d:%02d",seconds/60,seconds%60);
    }
    private void saveHistory() {
        if (playing == null || playing.url == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("name", playing.name); o.put("url", playing.url);
            o.put("protocol", playing.protocolInfo); o.put("art", playing.artUri);
            o.put("seconds", seconds); o.put("duration",duration);
            preferences.edit().putString("history",o.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void resumeVideo() {
        String json = preferences.getString("history", "");
        if (json.isEmpty()) { toast("尚无保存的观看记录"); return; }
        try {
            JSONObject o = new JSONObject(json);
            Upnp.Item item = new Upnp.Item();
            item.name = o.optString("name","上次观看"); item.url = o.getString("url");
            item.protocolInfo = o.optString("protocol", ""); item.artUri = o.optString("art", "");
            startVideo(item, o.optLong("seconds", 0));
        } catch (Exception e) { toast("观看记录读取失败"); }
    }

    private class FileAdapter extends BaseAdapter {
        @Override public int getCount() { return displayed.size(); }
        @Override public Object getItem(int i) { return displayed.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View reused, ViewGroup parent) {
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(9), dp(7), dp(8), dp(7));
            row.setBackground(shape(i % 2 == 0 ? CARD : BG, 9));
            Upnp.Item item = displayed.get(i);
            ImageView thumb = new ImageView(MainActivity.this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setBackground(shape(Color.rgb(49,60,74), 6));
            LinearLayout.LayoutParams ip = lp(dp(95), dp(62));
            row.addView(thumb, ip);
            LinearLayout body = new LinearLayout(MainActivity.this);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(dp(11), dp(3), dp(3), 0);
            TextView name = label((item.folder ? "📁 " : "") + item.name, 14, true, TEXT);
            name.setMaxLines(2); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            body.addView(name, lp(-1, -2));
            TextView desc = label(item.folder ? "文件夹 · 点击打开" : "视频 · 点击在 Vimu 播放", 11, false, SUB);
            body.addView(desc, lp(-1, -2));
            row.addView(body, new LinearLayout.LayoutParams(0, -2, 1));
            if (item.folder) thumb.setImageResource(android.R.drawable.ic_menu_agenda);
            else loadThumbnail(item, thumb);
            return row;
        }
    }
    private void loadThumbnail(Upnp.Item item, ImageView view) {
        String key = item.url == null ? item.name : item.url;
        view.setTag(key);
        Bitmap cached = imageCache.get(key);
        if (cached != null) { view.setImageBitmap(cached); return; }
        view.setImageResource(android.R.drawable.ic_media_play);
        if (imageRequests.contains(key) || failedImages.contains(key)) return;
        imageRequests.add(key);
        pictures.submit(() -> {
            Bitmap bitmap = null;
            try {
                if (item.artUri != null && !item.artUri.isEmpty()) bitmap = downloadBitmap(item.artUri);
                if (bitmap == null && item.url != null) {
                    // Best-effort frame extraction; some NAS DLNA links do not allow seeking.
                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                    try {
                        retriever.setDataSource(item.url, new java.util.HashMap<String, String>());
                        Bitmap frame = retriever.getFrameAtTime(2_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                        if (frame != null) {
                            int width = Math.min(frame.getWidth(), dp(190));
                            int height = Math.max(1, frame.getHeight() * width / Math.max(1,frame.getWidth()));
                            bitmap = Bitmap.createScaledBitmap(frame, width, height, true);
                            if (frame != bitmap) frame.recycle();
                        }
                    } finally { try { retriever.release(); } catch (Exception ignored) {} }
                }
            } catch (Exception ignored) {}
            final Bitmap resolved = bitmap;
            if (resolved != null) imageCache.put(key, resolved);
            else failedImages.add(key);
            imageRequests.remove(key);
            ui.post(() -> {
                if (!screenAlive || !key.equals(view.getTag())) return;
                if (resolved != null) view.setImageBitmap(resolved);
            });
        });
    }
    private Bitmap downloadBitmap(String link) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(link).openConnection();
            c.setConnectTimeout(3000); c.setReadTimeout(4000);
            c.setRequestProperty("Accept", "image/*");
            try (InputStream is = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] bytes = new byte[8192]; int n; int size = 0;
                while ((n = is.read(bytes)) != -1) {
                    size += n;
                    if (size > 4_000_000) return null;
                    out.write(bytes, 0, n);
                }
                byte[] raw = out.toByteArray();
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2;
                return BitmapFactory.decodeByteArray(raw, 0, raw.length, options);
            }
        } catch (Exception e) { return null; }
        finally { if (c != null) c.disconnect(); }
    }
}
