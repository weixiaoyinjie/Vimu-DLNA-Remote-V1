package com.vimudlna.remote;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

/** Local-network UPnP/DLNA implementation. All operations are synchronous: run from worker threads. */
public final class Upnp {
    private Upnp() {}

    public static class Device {
        public String name, udn, location, kind;
        public String controlUrl, serviceType;
        @Override public String toString() { return name + " (" + kind + ")"; }
    }

    public static class Item {
        public String id, parentId, name, url, protocolInfo, artUri, mediaClass;
        public boolean isVideo() {
            if (folder) return false;
            String mc = mediaClass == null ? "" : mediaClass.toLowerCase(Locale.ROOT);
            String pi = protocolInfo == null ? "" : protocolInfo.toLowerCase(Locale.ROOT);
            String path = url == null ? "" : url.toLowerCase(Locale.ROOT).split("\\?")[0];
            String label = name == null ? "" : name.toLowerCase(Locale.ROOT);
            if (mc.contains("videoitem") || pi.contains("video/")) return true;
            if (mc.contains("audioitem") || mc.contains("imageitem") || pi.contains("audio/") || pi.contains("image/")) return false;
            return path.matches(".*\\.(mkv|mp4|avi|mov|m4v|wmv|ts|m2ts|mpeg|mpg|webm|flv)$") ||
                    label.matches(".*\\.(mkv|mp4|avi|mov|m4v|wmv|ts|m2ts|mpeg|mpg|webm|flv)$");
        }
        public boolean folder;
        @Override public String toString() { return (folder ? "📁 " : "▶  ") + name; }
    }

    public static class Position {
        public long seconds, duration;
        public String state = "";
    }

    private static Document parse(InputStream is) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        f.setFeature("http://xml.org/sax/features/external-general-entities", false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(is);
    }

    private static Document parse(String xml) throws Exception {
        return parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    private static String text(Element el, String local) {
        if (el == null) return "";
        NodeList n = el.getElementsByTagNameNS("*", local);
        if (n.getLength() == 0) n = el.getElementsByTagName(local);
        return n.getLength() == 0 ? "" : n.item(0).getTextContent().trim();
    }

    private static String text(Document doc, String local) {
        return text(doc.getDocumentElement(), local);
    }

    private static String esc(String x) {
        if (x == null) return "";
        return x.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String readAll(InputStream input) throws Exception {
        try (InputStream is = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n;
            while ((n = is.read(b)) > 0) out.write(b, 0, n);
            return out.toString("UTF-8");
        }
    }

    private static Document getXml(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(3500); c.setReadTimeout(4500);
        c.setRequestProperty("User-Agent", "VimuDLNARemote/1.0 UPnP/1.1");
        try { return parse(c.getInputStream()); } finally { c.disconnect(); }
    }

    private static Device parseDevice(String location) throws Exception {
        Document desc = getXml(location);
        NodeList nodes = desc.getElementsByTagNameNS("*", "device");
        if (nodes.getLength() == 0) nodes = desc.getElementsByTagName("device");
        for (int j=0; j<nodes.getLength(); j++) {
            Element deviceEl = (Element) nodes.item(j);
            String deviceType = text(deviceEl, "deviceType");
            boolean isRenderer = deviceType.contains("MediaRenderer");
            boolean isServer = deviceType.contains("MediaServer");
            if (!isRenderer && !isServer) continue;
            String match = isRenderer ? "AVTransport" : "ContentDirectory";
            NodeList services = deviceEl.getElementsByTagNameNS("*", "service");
            if (services.getLength() == 0) services = deviceEl.getElementsByTagName("service");
            for (int i=0; i<services.getLength(); i++) {
                Element s = (Element) services.item(i);
                String type = text(s, "serviceType");
                if (!type.contains(match)) continue;
                String ctl = text(s, "controlURL");
                if (ctl.isEmpty()) continue;
                Device d = new Device();
                d.name = text(deviceEl, "friendlyName");
                if (d.name.isEmpty()) d.name = isRenderer ? "DLNA 播放器" : "DLNA 硬盘";
                d.udn = text(deviceEl, "UDN"); d.location = location;
                d.kind = isRenderer ? "Vimu/Renderer" : "媒体库/Server";
                String base = text(desc, "URLBase");
                String rootUrl = base.isEmpty() ? location : base;
                d.controlUrl = new URI(rootUrl).resolve(ctl).toString();
                d.serviceType = type;
                return d;
            }
        }
        return null;
    }

    /** Multi-ST SSDP M-SEARCH; no external server or API key required. */
    public static ArrayList<Device> discover() throws Exception {
        Map<String, Device> found = new LinkedHashMap<>();
        Map<String, Boolean> locations = new LinkedHashMap<>();
        try (DatagramSocket sock = new DatagramSocket()) {
            sock.setSoTimeout(650);
            InetAddress multicast = InetAddress.getByName("239.255.255.250");
            String[] targets = { "ssdp:all", "urn:schemas-upnp-org:device:MediaRenderer:1",
                    "urn:schemas-upnp-org:device:MediaServer:1" };
            for (String st : targets) {
                String m = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n";
                byte[] bytes = m.getBytes(StandardCharsets.UTF_8);
                sock.send(new DatagramPacket(bytes, bytes.length, multicast, 1900));
            }
            long until = System.currentTimeMillis() + 3800;
            while (System.currentTimeMillis() < until) {
                byte[] buf = new byte[8192];
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try { sock.receive(p); }
                catch (java.net.SocketTimeoutException timeout) { continue; }
                String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                for (String line : msg.split("\\r?\\n")) {
                    int col = line.indexOf(':');
                    if (col < 0) continue;
                    if (line.substring(0, col).trim().equalsIgnoreCase("LOCATION")) {
                        String u = line.substring(col + 1).trim();
                        if (u.startsWith("http://") || u.startsWith("https://")) locations.put(u, true);
                    }
                }
            }
        }
        for (String location : locations.keySet()) {
            try {
                Device d = parseDevice(location);
                if (d != null) found.put(d.kind + ":" + (d.udn.isEmpty() ? d.location : d.udn), d);
            } catch (Exception ignored) { /* Other devices can publish invalid SSDP descriptions */ }
        }
        return new ArrayList<>(found.values());
    }

    private static Document soap(Device d, String action, String innerXml) throws Exception {
        if (d == null || d.controlUrl == null) throw new IllegalStateException("尚未连接设备");
        String envelope = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                "<s:Body><u:" + action + " xmlns:u=\"" + esc(d.serviceType) + "\">" +
                innerXml + "</u:" + action + "></s:Body></s:Envelope>";
        byte[] bytes = envelope.getBytes(StandardCharsets.UTF_8);
        HttpURLConnection c = (HttpURLConnection) new URL(d.controlUrl).openConnection();
        c.setConnectTimeout(4500); c.setReadTimeout(6500);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        c.setRequestProperty("SOAPAction", "\"" + d.serviceType + "#" + action + "\"");
        c.setFixedLengthStreamingMode(bytes.length);
        try {
            try (java.io.OutputStream os = c.getOutputStream()) { os.write(bytes); }
            int status = c.getResponseCode();
            String result = readAll(status >= 400 ? c.getErrorStream() : c.getInputStream());
            if (status >= 400) {
                String reason = "HTTP " + status;
                try { String fault = text(parse(result), "errorDescription"); if (!fault.isEmpty()) reason += " — " + fault; }
                catch (Exception ignored) {}
                throw new IllegalStateException(action + "：" + reason);
            }
            return parse(result);
        } finally { c.disconnect(); }
    }

    public static ArrayList<Item> browse(Device server, String objectId) throws Exception {
        // Paginate because some DLNA servers silently cap each Browse result.
        ArrayList<Item> items = new ArrayList<>();
        int offset = 0;
        for (int page=0; page<30; page++) {
            String params = "<ObjectID>" + esc(objectId) + "</ObjectID>" +
                    "<BrowseFlag>BrowseDirectChildren</BrowseFlag><Filter>*</Filter>" +
                    "<StartingIndex>" + offset + "</StartingIndex>" +
                    "<RequestedCount>100</RequestedCount><SortCriteria></SortCriteria>";
            Document d = soap(server, "Browse", params);
            String result = text(d, "Result");
            if (result.isEmpty()) break;
            Document content = parse(result);
            NodeList n = content.getDocumentElement().getChildNodes();
            int retrieved = 0;
            for (int i=0; i<n.getLength(); i++) {
                if (!(n.item(i) instanceof Element)) continue;
                Element el = (Element) n.item(i);
                String label = el.getLocalName() == null ? el.getTagName() : el.getLocalName();
                if (!"container".equals(label) && !"item".equals(label)) continue;
                retrieved++;
                Item item = new Item();
                item.folder = "container".equals(label);
                item.id = el.getAttribute("id"); item.parentId = el.getAttribute("parentID");
                item.name = text(el, "title");
                item.mediaClass = text(el, "class");
                item.artUri = text(el, "albumArtURI");
                if (item.name.isEmpty()) item.name = item.id;
                if (!item.folder) {
                    NodeList resources = el.getElementsByTagNameNS("*", "res");
                    if (resources.getLength() == 0) resources = el.getElementsByTagName("res");
                    // Prefer an HTTP video resource; unlike an SMB URL it can be fetched by the TV.
                    for (int j=0; j<resources.getLength(); j++) {
                        Element re = (Element) resources.item(j);
                        String pi = re.getAttribute("protocolInfo");
                        String url = re.getTextContent().trim();
                        if (url.isEmpty() || !url.startsWith("http")) continue;
                        if (item.url == null || pi.toLowerCase(Locale.ROOT).contains("video/")) {
                            item.url = url; item.protocolInfo = pi;
                        }
                        if (pi.toLowerCase(Locale.ROOT).contains("video/")) break;
                    }
                }
                if (item.artUri != null && !item.artUri.isEmpty()) {
                    try { item.artUri = new URI(server.location).resolve(item.artUri).toString(); }
                    catch (Exception ignored) { item.artUri = ""; }
                }
                items.add(item);
            }
            int read = retrieved;
            offset += read;
            int total = intOr(text(d, "TotalMatches"), read);
            if (read == 0 || offset >= total) break;
        }
        return items;
    }

    private static int intOr(String s, int fallback) {
        try { return Integer.parseInt(s); } catch (Exception e) { return fallback; }
    }

    private static String metadata(Item item) {
        String pi = (item.protocolInfo == null || item.protocolInfo.isEmpty()) ? "http-get:*:video/mp4:*" : item.protocolInfo;
        return "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
                "<item id=\"0\" parentID=\"0\" restricted=\"1\">" +
                "<dc:title>" + esc(item.name) + "</dc:title>" +
                "<upnp:class>object.item.videoItem</upnp:class>" +
                "<res protocolInfo=\"" + esc(pi) + "\">" + esc(item.url) + "</res>" +
                "</item></DIDL-Lite>";
    }

    public static void play(Device renderer, Item item) throws Exception {
        if (item == null || item.url == null) throw new IllegalArgumentException("该文件没有可用的 DLNA 视频地址");
        String prefix = "<InstanceID>0</InstanceID><CurrentURI>" + esc(item.url) + "</CurrentURI>";
        try { soap(renderer, "SetAVTransportURI", prefix + "<CurrentURIMetaData>" + esc(metadata(item)) + "</CurrentURIMetaData>"); }
        catch (Exception e) { // Some renderers reject rich DIDL-Lite; retry with empty metadata.
            soap(renderer, "SetAVTransportURI", prefix + "<CurrentURIMetaData></CurrentURIMetaData>");
        }
        soap(renderer, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>");
    }

    public static void command(Device renderer, String action) throws Exception {
        String payload = "<InstanceID>0</InstanceID>";
        if ("Play".equals(action)) payload += "<Speed>1</Speed>";
        soap(renderer, action, payload);
    }

    public static void seek(Device renderer, long seconds) throws Exception {
        long h = Math.max(0, seconds) / 3600;
        long m = (Math.max(0, seconds) % 3600) / 60;
        long s = Math.max(0, seconds) % 60;
        String time = String.format(Locale.US, "%02d:%02d:%02d", h,m,s);
        soap(renderer, "Seek", "<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>" + time + "</Target>");
    }

    private static long asTime(String s) {
        try {
            String[] parts = s.split(":");
            if (parts.length != 3) return 0;
            return Integer.parseInt(parts[0])*3600L + Integer.parseInt(parts[1])*60L +
                    (long)Double.parseDouble(parts[2]);
        } catch (Exception e) { return 0; }
    }

    public static Position position(Device renderer) throws Exception {
        Document p = soap(renderer, "GetPositionInfo", "<InstanceID>0</InstanceID>");
        Position result = new Position();
        result.seconds = asTime(text(p, "RelTime"));
        result.duration = asTime(text(p, "TrackDuration"));
        try {
            Document state = soap(renderer, "GetTransportInfo", "<InstanceID>0</InstanceID>");
            result.state = text(state, "CurrentTransportState");
        } catch (Exception ignored) { /* some UPnP renderers do not expose transport state */ }
        return result;
    }
}
