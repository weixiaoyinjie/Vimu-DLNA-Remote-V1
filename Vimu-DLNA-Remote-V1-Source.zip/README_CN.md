# Vimu DLNA Remote V1.0（安卓手机）

## 使用架构

**手机 App 只负责发现、浏览、封面和发送控制命令。**
实际影片视频数据直接沿着 `DLNA/UPnP 硬盘 → Google TV 的 Vimu` 传输；不使用手机代理、转发、转码视频。

所需设备：同一局域网内的安卓手机、安装并开启 Vimu 的 Google TV、已开启 DLNA/UPnP 服务器的硬盘。
不需要 Vimu API Key，不需要在电视另外安装 App，不需要 SMB 登录信息。

## V1.0 功能

- SSDP 自动发现 UPnP AVTransport MediaRenderer（建议手动确认选择 Vimu）
- SSDP 自动发现 DLNA ContentDirectory MediaServer 硬盘
- 点击进入目录；自然顺序排序影片和剧集文件名
- 显示每段视频的缩微图：优先 UPnP albumArtURI，如无则尝试从 DLNA 视频地址读取一帧；服务器不支持则显示默认播放图标
- 点击影片，调用 `SetAVTransportURI` + `Play`，由电视直接拉取硬盘资源
- 播放/暂停/停止、前后 30 秒、进度条 Seek
- 获取播放进度和时长（取决于 Vimu DLNA 服务支持）
- 本地保存最近一次观看进度；“继续观看”重新推送并尝试 seek
- 同一文件夹内上一部/下一部（由手机端选择并发送新的视频 URI）
- 记住曾选择的设备 ID，支持重新搜索并在 IP 变更后匹配

## Android 构建

开发：Java 17，Android Gradle Plugin 8.7.3，Gradle 8.11.1，compileSdk 35，minSdk 26。
不使用外部第三方依赖。项目使用 GitHub Actions 编译 `app-debug.apk`。

### 按你惯用的“上传 ZIP 不解压”方法

1. 新建一个 **空的** GitHub 仓库，推荐名称 `Vimu-DLNA-Remote-V1`，主分支使用 `main`。
2. 将 `Vimu-DLNA-Remote-V1-Source.zip` 不解压直接上传到仓库根目录。
3. 在仓库创建 `.github/workflows/build-apk.yml`，复制另附的 `build-apk.yml` 内容。
4. GitHub Actions → `Build Vimu DLNA Remote APK` → `Run workflow`，或直接提交 ZIP 和 workflow 触发。
5. 构建成功后点击最新一次 Run → Artifacts → `Vimu-DLNA-Remote-V1-APK`，下载 zip，解压取得 `app-debug.apk` 安装在 **手机**。

不要把源码 ZIP 传到 Actions 工作流文件夹，不需要电视安装 APK。

## 使用方法

1. 手机和电视、DLNA 硬盘在同一局域网内；Vimu 保持打开，硬盘开启 UPnP/DLNA 服务。
2. 打开手机 App，等待自动扫描；在「电视播放器」下拉选择 **Vimu**，在「DLNA/UPnP 硬盘」下拉选择你的硬盘。
3. 进入文件夹，手机看到封面和影片列表；点击影片即可在 Vimu 上直接播放。
4. 使用底部遥控条暂停、调整进度、前后 30 秒、上一部/下一部、停止、继续观看。
5. 若 DLNA 硬盘重新开机导致 IP 变化，按「搜索设备」重新发现。

## 边界与兼容性

- **Vimu 官方 Intent API 并未在跨设备模式下启用。** 本 App 使用标准 DLNA/UPnP API，而不是 `forcedsrt` 等 Android Intent 参数。
- **封面显示并非保证**：某些 DLNA 硬盘不返回封面、也不支持 Android 提取视频首帧。此时显示默认播放图标，不影响点击播放。
- 抓取缩微图可能从硬盘向手机读取少量图像/视频数据，但**正式视频播放完全不经过手机**。
- DLNA 客户端需要 Vimu 暴露 `AVTransport` 服务；暂停、快进已经在你自己的 BubbleUPnP 测试中正常，但本 App 仍需实际设备测试。
- 播放总时长、跳转和恢复播放取决于 DLNA 协议实现及视频流对 Range/Seek 的支持；个别格式可能无效。
- 上一部/下一部由手机发送指令，并非电视内部播放队列；关闭手机 App 后不会自动切换下一部。
- 如果电视和手机接入了不同隔离的 Wi-Fi（AP/client isolation），SSDP 发现可能失败。
- Google TV 可能同时显示 Chromecast 和 Vimu DLNA 设备；请选名称带 Vimu 的 **UPnP Renderer**，不是单纯的 Chromecast。
- 本项目仅在本地进行协议层模拟测试。**未在你的真实电视/硬盘上编译或实机验证 APK**；Actions 构建结果以仓库运行记录为准。
